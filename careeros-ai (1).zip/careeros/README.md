# CareerOS AI

The nine original screens merged into one static multi-page app. Open `index.html`. No build step.

## Pages and flow

| File | Feature | Was |
|---|---|---|
| `index.html` | Landing | `CareerOS_AI.html` |
| `auth.html` | Login / signup / forgot password (+ quick onboarding at `#/onboarding`) | `...Login__Signup___Onboarding.html` |
| `profile.html` | Profile builder | `...Profile_Onboarding.html` |
| `assessment.html` | Timed skills assessment | `careeros-assessment.html` |
| `dashboard.html` | Student dashboard | `..._student_dashboard.html` |
| `roadmap.html` | 30/60/90-day roadmap | `..._career_roadmap.html` |
| `resume.html` | Resume analyzer | `..._resume_analyzer.html` |
| `interview.html` | Interview simulator | `..._interview_simulator__Copy_.html` |
| `coach.html` | Career coach | `..._career_coach.html` |

Flow: landing -> signup -> profile -> assessment -> roadmap -> dashboard. Login -> dashboard.
Dashboard, roadmap, resume, interview and coach share the sidebar. Landing, auth, profile and assessment keep their own focused layouts.

## Shared code (`assets/`)

- `routes.js`: every page URL in one object (`ROUTES`). Change a path here only.
- `base.css`: design tokens (`:root`) plus declarations that were identical on every page using them.
- `shell.css` / `shell.js`: the sidebar (from the dashboard), mobile top bar and drawer. Enable with `<body data-shell data-page="...">`.

## Not done on purpose

- Resume report, interview scoring and coach replies are still the original sample/heuristic logic. No AI or backend added.
- Nothing is persisted between pages (assessment score, profile answers). The `api` stubs in each page are the hook points. Roadmap keeps its existing `localStorage` progress.
- Log out is only a link to the login page until real auth exists.
