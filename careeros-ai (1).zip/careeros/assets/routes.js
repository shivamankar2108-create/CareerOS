/* CareerOS AI: single source of truth for page URLs.
   Change a path here and every redirect and the app sidebar follow. */
window.ROUTES = {
  home: 'index.html',
  login: 'auth.html#/login',
  signup: 'auth.html#/signup',
  forgot: 'auth.html#/forgot',
  profile: 'profile.html',
  assessment: 'assessment.html',
  dashboard: 'dashboard.html',
  roadmap: 'roadmap.html',
  resume: 'resume.html',
  interview: 'interview.html',
  coach: 'coach.html'
};
