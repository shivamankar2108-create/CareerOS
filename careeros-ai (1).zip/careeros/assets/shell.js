/* CareerOS AI app shell. Load right after <body data-shell data-page="...">.
   Needs assets/routes.js. Optional: data-next-up="text" on <body> shows the "Next up" card. */
(function () {
  var R = window.ROUTES || {}, b = document.body, page = b.dataset.page || '';
  var svg = function (d) { return '<svg class="os-i" viewBox="0 0 24 24" aria-hidden="true">' + d + '</svg>'; };
  var SPARK = '<path d="M12 3l2.5 6.5L21 12l-6.5 2.5L12 21l-2.5-6.5L3 12l6.5-2.5z"/>';
  var NAV = [
    ['dashboard', 'Dashboard', '<rect x="3" y="3" width="7" height="9" rx="2"/><rect x="14" y="3" width="7" height="5" rx="2"/><rect x="14" y="12" width="7" height="9" rx="2"/><rect x="3" y="16" width="7" height="5" rx="2"/>'],
    ['assessment', 'Assessment', '<path d="M9 11l3 3 8-8"/><path d="M20 12v7a2 2 0 01-2 2H6a2 2 0 01-2-2V5a2 2 0 012-2h9"/>'],
    ['roadmap', 'Roadmap', '<path d="M3 6l6-3 6 3 6-3v15l-6 3-6-3-6 3z"/>'],
    ['resume', 'Resume', '<path d="M14 3H7a2 2 0 00-2 2v14a2 2 0 002 2h10a2 2 0 002-2V8z"/><path d="M14 3v5h5"/>'],
    ['interview', 'Interview practice', '<path d="M21 15a2 2 0 01-2 2H8l-5 4V5a2 2 0 012-2h14a2 2 0 012 2z"/>'],
    ['coach', 'Career coach', SPARK],
    ['profile', 'Profile', '<circle cx="12" cy="8" r="4"/><path d="M4 21a8 8 0 0116 0"/>']
  ];
  var logo = '<a class="os-logo" href="' + R.dashboard + '" aria-label="CareerOS AI dashboard"><span class="os-mark">' + svg(SPARK) + '</span>CareerOS AI</a>';

  var side = document.createElement('aside');
  side.className = 'os-side'; side.id = 'os-side'; side.setAttribute('aria-label', 'Main navigation');
  side.innerHTML = logo + '<nav class="os-nav" aria-label="Primary">' + NAV.map(function (n) {
    return '<a href="' + R[n[0]] + '"' + (n[0] === page ? ' aria-current="page"' : '') + '>' + svg(n[2]) + n[1] + '</a>';
  }).join('') + '</nav><div class="os-up" hidden><b>Next up</b><span></span></div>' +
    '<a class="os-out" href="' + R.login + '">' + svg('<path d="M9 21H5a2 2 0 01-2-2V5a2 2 0 012-2h4M16 17l5-5-5-5M21 12H9"/>') + 'Log out</a>';

  var mbar = document.createElement('div');
  mbar.className = 'os-mbar';
  mbar.innerHTML = '<button class="os-burger" type="button" aria-label="Open menu" aria-controls="os-side" aria-expanded="false">' + svg('<path d="M4 7h16M4 12h16M4 17h16"/>') + '</button>' + logo;

  var scrim = document.createElement('div');
  scrim.className = 'os-scrim';

  var next = b.dataset.nextUp;
  if (next) { var up = side.querySelector('.os-up'); up.hidden = false; up.querySelector('span').textContent = next; }

  b.prepend(mbar, side, scrim);

  var burger = mbar.querySelector('.os-burger');
  var toggle = function (open) { b.classList.toggle('os-open', open); burger.setAttribute('aria-expanded', open); };
  burger.addEventListener('click', function () { toggle(true); });
  scrim.addEventListener('click', function () { toggle(false); });
  side.addEventListener('click', function (e) { if (e.target.closest('a')) toggle(false); });
  document.addEventListener('keydown', function (e) { if (e.key === 'Escape') toggle(false); });
})();
